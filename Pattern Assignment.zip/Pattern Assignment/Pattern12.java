
package Assignment_27;
//Star and space pattern
public class Pattern12 {

 public static void main(String[] args) {
     
     int rows = 5; // Number of rows
     int space = rows - 1; // Initial space count

     for (int i = 0; i < rows; i++) {
         // Print spaces
         for (int k = 0; k < space; k++) {
             System.out.print(" "); // Use print to stay on the same line
         }
         // Print stars
         for (int l = 0; l < (2 * i + 1); l++) { // Odd number of stars
             System.out.print("*"); // Use print to stay on the same line
         }
         System.out.println(); // Move to the next line after printing stars
         space--; // Decrease space count for the next row
     }
 }
}
