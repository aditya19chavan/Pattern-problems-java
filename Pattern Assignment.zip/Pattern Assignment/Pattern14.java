
/* ******
 * ****
 * ***
 * **
 * *
 * 
 */






package Assignment_27;

//star and space pattern
public class Pattern14 {

	public static void main(String[] args) {

		int row = 5;
		int col = 5;
		for (int i = 1; i <= row; i++)
		{
			for (int j = 1; j <=col ; j++)
			{
				System.out.print("*");
			}
			col--;
System.out.println();
		}
	}
}
