package remainingproblems;

public class Pattern28 {

	public static void main(String[] args) {
	int sp=6;
	int st=1;
	int n=6;
		
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<sp;j++)
			{
				System.out.print(" ");
			}
			for(int k=0;k<st;k++) {
				
				if(k==0 || k==i || i==n-1)
					System.out.print("*"+" ");
				else
					System.out.print(" "+" ");
				
			}
			st++;
			sp--;
			System.out.println();
		}
         
	}

	}


