package Assignment_27;

public class Pattern4 {

	public static void main(String[] args) {
		for (int i = 0; i < 6; i++) {
			for (int j = 1; j < 6; j++) {
				System.out.print((i+j)%2+" ");
			}

			System.out.println();
		}

	}

}
