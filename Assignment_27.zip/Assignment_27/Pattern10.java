package Assignment_27;

public class Pattern10 {

	public static void main(String[] args) {
		int k=1;
	    for(int i=1;i<7;i++) {
	    	   for(int j=0;j<i;j++) {
	    		   System.out.print(k+j +" ");
	    	   }
	    	   k++;
	    	   System.out.println();
	       }

	}

}
