package Assignment_27;

public class Pattern15 {

	public static void main(String[] args) {
		int n=5;
		
		for(int i=0;i<5;i++) {
			for(int j=i;j<5;j++) {
				System.out.print(n);
			}
			n--;
			System.out.println();
		}
         
	}

}
